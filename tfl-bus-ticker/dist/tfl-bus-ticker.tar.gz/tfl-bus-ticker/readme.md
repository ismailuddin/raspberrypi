# TfL Bus Arrivals Ticker
Raspberry Pi project to display the latest bus arrivals for a given bus stop in London on a Hitachi HD44780 based 16x2 character LCD.
